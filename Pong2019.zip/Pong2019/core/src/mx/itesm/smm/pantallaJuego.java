package mx.itesm.smm;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

class pantallaJuego implements Screen {
    private final Pong pong;

    //Tamaño del "mundo" (pantalla)
    public static final float ANCHO = 1200;
    public static final float ALTO = 800;

    //Cámara

    private OrthographicCamera camera;
    private Viewport view;

    //Administrador sobre pantalla
    public SpriteBatch batch;

    //Texturas para el juego

    private Texture texturaBarraHor;
    private Texture texturaRaqueta;
    private Texture texturaCuadro;

    public pantallaJuego(Pong pong){
        this.pong = pong;
    }

    //Este método se ejecuta la vista en la pantalla
    @Override
    public void show() {
        //Crear la cámara
        camera = new OrthographicCamera(ANCHO, ALTO);
        camera.position.set(ANCHO/2, ALTO/2, 0);
        camera.update();

        view = new StretchViewport(ANCHO, ALTO, camera);
        batch = new SpriteBatch();

        //Carga de Texturas
        cargarTexturas();

    }

    private void cargarTexturas() {
        texturaBarraHor = new Texture("barraHorizontal.png");
        texturaRaqueta = new Texture("raqueta.png");
        texturaCuadro = new Texture("cuadrito.png");


    }


    //Este método dibuja en la pantalla, aproximadamente a 60 FPS

    @Override
    public void render(float delta) {
        //Borra la pantalla
        Gdx.gl.glClearColor(0,0,0,1); //Negro, opaco
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        batch.setProjectionMatrix(camera.combined);

        batch.begin(); //Aqui empieza el dibujo del juego
        batch.draw(texturaBarraHor, 0,0);
        batch.draw(texturaBarraHor, 0, ALTO - texturaBarraHor.getHeight());
        // Linea horizontal
        for(float y=0; y< ALTO; y+= 2* texturaCuadro.getHeight()){
            batch.draw(texturaCuadro, ANCHO/ 2 , y);
        }
        //Raquetas
        batch.draw(texturaRaqueta, 0, ALTO/2);
        batch.draw(texturaRaqueta, ANCHO - texturaRaqueta.getWidth(), ALTO/2);
        batch.end();
    }


    //Se ejecuta cuando se cambia de tamaño la pantalla
    @Override
    public void resize(int width, int height) {
        view.update(width, height);
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
